// JavaScript Document
function confirmInfo() {
  alert("Transaction Complete! Thank you " + document.forum.name.value + ", for donating a value of " + document.forum.amount.value + ". We appreciate this donation and will use this to make students' education much better.");

window.location = '../';
}
